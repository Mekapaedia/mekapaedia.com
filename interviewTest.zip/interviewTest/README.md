# WaveRead

This is a program made to the specifications set by Pico Technologies as an interview coding test. I completed this on the 23rd of July, 2020.

This solution I created is called WaveRead, in reference to WaveGen. It is intended to be a reasonable demonstration of my coding ability, and is intended to be reasonably modular and maintainable.
A 32-bit precompiled binary is included, but in cplus\WaveRead you can find the project file (.sln) and C++ code files that can be used to compile the program on your machine.

WaveRead has a few useage flags, as I am a sucker for adding in command line flags. The useage is below (taken directly from WaveRead's help):
```
Welcome to WaveRead v1.0 by Ryan Harvey

This program takes all the files in a specified directory with the format Wave*.csv and outputs a CSV file detailing the frequency of each file.
By default, that file will be called WaveRead$TIMESTAMP.csv and will be saved in the current directory.


Usage is as follows:
-h: This help
-d $DIRECTORY: Specify the directory to search for Wave files in. If unspecified, the current working directory will be used.
-D $DIRECTORY: Specify the directory to output the analysis file. If unspecified, the current working directory will be used.
-o $OUTPUT_FILE: Specify the full path of the output file. -D will be ignored if this is specified. If - is used the output will be the console.
-v: Extra information on what the program is actually doing. Put in because with 420 files, the program takes ages.
-f n: Assuming the Wave*.csv files are numbered in increasing monotonic order, this option is to skip n-1 files and start with file n. Zero indexed.
-l n: Assuming the Wave*.csv files are numbered in increasing monotonic order, this option is to stop on file n. Zero indexed.
```

Thank you for reading! If you want to get in contact with me you can go to my website at <http://mekapaedia.com> or email me at rkharvey@mekapaedia.com.
