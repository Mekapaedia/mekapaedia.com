## Compilation
To compile and run this, just open the .sln in Visual Studio. It was made in VS2019, so it should work on recent versions.

If that doesn't work, compiling together the files manually should be fine so long as they are still able to reference the Windows-specific Win32 API libraries. This code is *not* cross-platform.