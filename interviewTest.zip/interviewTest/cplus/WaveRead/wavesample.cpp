/* WaveRead Version 1.0 by Ryan Harvey, submitted for consideration to Pico Technologies. */
/* Website: http://mekapaedia.com */
/* Email: rkharvey@mekapaedia.com */
/* This version completed as of the 24th of July, 2020. */
/* LICENSE INFORMATION: eh, would appreciate if you sent me a note if you use this, but honestly not fussed. Do what you want with this code. */
/* SUPPORT INFORMATION: email me I guess, but it's not really designed for commercial use. */

/*
wavesample.cpp

This class is largely a container class for the time and voltage samples, along with some utility functions.

*/

#include "WaveRead.h" //Our favourite header.

namespace WaveRead //Don't mess up the std namespace.
{
	wavesample::wavesample() //Constructors
	{
		set_time(0);
		set_volts(0);
	}

	wavesample::wavesample(double t, double v)
	{
		set_time(t);
		set_volts(v);
	}

	void wavesample::set_time(double t)
	{
		time = t;
	}
	void wavesample::set_volts(double v)
	{
		volts = v;
	}

	double wavesample::get_time() //Getters 
	{
		return time;
	}
	double wavesample::get_volts()
	{
		return volts;
	}

	std::wstring wavesample::toCSV() //Quick function to return this sample in a CSV representation, by default with a comma seperator
	{
		return wavesample::toCSV(',');
	}
	std::wstring wavesample::toCSV(char seperator)
	{
		return std::to_wstring(time) + std::to_wstring(seperator) + TEXT(" ") + std::to_wstring(volts) + TEXT("\n");
	}
}