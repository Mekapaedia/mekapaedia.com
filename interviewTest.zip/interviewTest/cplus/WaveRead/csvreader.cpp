/* WaveRead Version 1.0 by Ryan Harvey, submitted for consideration to Pico Technologies. */
/* Website: http://mekapaedia.com */
/* Email: rkharvey@mekapaedia.com */
/* This version completed as of the 24th of July, 2020. */
/* LICENSE INFORMATION: eh, would appreciate if you sent me a note if you use this, but honestly not fussed. Do what you want with this code. */
/* SUPPORT INFORMATION: email me I guess, but it's not really designed for commercial use. */

/*
csvreader.cpp

This is a handwritten one pass naive CSV parser specifically for the file format provided.

It would have probably been better to use a library but this works alright.

*/

#include "WaveRead.h"

namespace WaveRead
{
	csvreader::csvreader() //Constructor
	{
		headers = new std::vector<TCHAR*>; //Headers, used to find the seperator (which should be a command anyways)
		this->reset(); //Resets all pointers to the start
	}
	csvreader::csvreader(TCHAR* csv_file)
	{
		headers = new std::vector<TCHAR*>;
		this->set_csv(csv_file);
	}

	void csvreader::reset()
	{
		csv_buf = nullptr; //Get a new buffer for the raw csv data
		cols = 0; //We assume we don't know how many columns
		pos = 0; //Reset to the start of the file
		len = 0; //Don't know the length
		status = 0; //0 means "not yet read", should probably be an enum.
		delim = 0; //We don't know what the delimiter character is (but it should be a comma)
		headers_end = 0; //Position of the end of the headers in the csv buffer - haven't read anything yet.
		headers->clear();
	}

	void csvreader::reset_pos() //This is to reset the position of the csvreader cursor but keeping the selected file.
	{
		pos = headers_end;
	}

	void csvreader::read_headers() //Read in the CSV headers and figure out what the record seperator is.
	{
		std::vector<TCHAR> candidate_seperators;
		len = _tcsclen(csv_buf); //The length of the file in wchars
		if (len < 2) //If it is literally just the EOF, there is no point
		{
			status = -1; //Error status, should be an enum
			return;
		}
		
		while (csv_buf[pos] != TEXT('\n')) //Assume the each newline is the end of the row, as per CSV standard. This only scans the first line which should be just the headers.
		{
			if (!iswalnum(csv_buf[pos]) && (csv_buf[pos] != TEXT('\r'))) //If it isn't an alphanumeric character or the carriage return, it might be a record seperator.
			{
				unique_add_seperator(&candidate_seperators, csv_buf[pos], csv_buf[pos-1]); //Add it to the candiates, but only one time.
			}
			pos++; //Keep scanning
		}
		
		if (candidate_seperators.size() == 1) //If we only find one candiate, which is good, use that one.
		{
			delim = candidate_seperators.at(0);
			candidate_seperators.clear();
		}

		else //Otherwise, inform the user that their CSV file is wonky.
		{
			for (size_t i = 0; i < candidate_seperators.size(); i++)
			{
				std::wcerr << TEXT("Ambiguous record delimiter, candidates listed below:") << std::endl;
				std::wcerr << std::to_wstring(i) + TEXT(": ") + candidate_seperators.at(i) + TEXT(" (") + std::to_wstring((long)candidate_seperators.at(i)) + TEXT(")") << std::endl;
			}
			status = -1;
			return; //If we cannot figure out the format, there's no point in trying to read it further.
		}

		int j = 0;
		TCHAR* temp_header = new TCHAR[(unsigned int) pos+1]; //Buffer for the current header
		memset(temp_header, 0, sizeof(TCHAR) * ((size_t) pos + 1)); //Zero it
		for (int i = 0; i < pos; i++) //This runs up to the newline we found which should be the end of the row
		{
			if (csv_buf[i] == delim || i == pos - 1) //If we find the delimiter, or are just before the end of the row, it should be the end of one of the headers
			{
				TCHAR* push_header = new TCHAR[j + 1]; //Add the header to the lost
				memset(push_header, 0, sizeof(TCHAR) * (j + 1));
				_tcsncpy_s(push_header, j+1, temp_header, _TRUNCATE);
				headers->push_back(push_header);
				j = 0; //Reset the position of the header buffer
				continue;
			}
			temp_header[j] = csv_buf[i]; //Add the next character to the header buffer
			temp_header[j + 1] = TEXT('\0'); //Zero terminate it
			j++;
		}
		cols = headers->size(); //The amount of headers we found should equal the amount of columns (should be 2)
		pos++; //Move to the first character after the newline
		headers_end = pos; //This is where our data starts
		status = 1; //Good status. Should be an enum
	}

	void csvreader::set_csv(TCHAR* csv_file) //This changes the pointer to the raw csv file buffer
	{
		this->reset();
		csv_buf = csv_file;
		read_headers();
	}

	int csvreader::get_cols() //getter functions
	{
		return cols;
	}
	
	std::vector<TCHAR*> *csvreader::get_headers()
	{
		return headers;
	}

	double csvreader::nextval() //Returns the next double value, in the order time, volts, time, volts... etc
	{
		double val = nan(""); //Start with a NaN, because if it isn't set that is detectable as a formatting error.
		TCHAR *buf;
		if (len - pos >= 1)   //As long as we are before the end of the document
		{
			buf = new TCHAR[(unsigned int) len - (unsigned int) pos + 1]; //Get a buffer the size of the rest of the document (maximum possibly required size)
			memset(buf, 0, (size_t) len - (size_t) pos); //Zero it
			int i = 0;
			while (isvalid_floatwc(csv_buf[pos]) && pos < len) //While the current character is a valid double character (i.e.: ., e, E, -, + or a number)
			{
				buf[i] = csv_buf[pos]; //If it is, add it to the conversion buffer
				i++;
				pos++; //And move forward
			}
			val = _tcstod(buf, NULL); //If we hit an invalid character, it should either be a record seperator or a newline
			delete[] buf;
			while (csv_buf[pos] == delim || csv_buf[pos] == TEXT('\r') || csv_buf[pos] == TEXT('\n') || csv_buf[pos] == TEXT(' ')) //If it is, this value should be formatted correctly
			{
				if (pos >= len) //This means we are at the end of the document, so leave
				{
					break;
				}
				pos++;
			}
		}
		if (errno != 0) //_tcstod() sets this non-zero if there is a conversion error
		{
			double val = nan(""); //so return NaN as the value would be garbage anyways
		}
		return val;
	}
	int csvreader::get_status() //Return the status, which should be positive if the file is read and has proper formatting.
	{
		return status;
	}
}