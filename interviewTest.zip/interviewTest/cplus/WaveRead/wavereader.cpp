/* WaveRead Version 1.0 by Ryan Harvey, submitted for consideration to Pico Technologies. */
/* Website: http://mekapaedia.com */
/* Email: rkharvey@mekapaedia.com */
/* This version completed as of the 24th of July, 2020. */
/* LICENSE INFORMATION: eh, would appreciate if you sent me a note if you use this, but honestly not fussed. Do what you want with this code. */
/* SUPPORT INFORMATION: email me I guess, but it's not really designed for commercial use. */

/*
wavereader.cpp

This is the class that does all the analysis. Each wavereader contains a list of wavesample measurement samples from the specified Wave csv file, 
and the functions needed to do analysis on those files. It calculates the amplitude, DC bias, DC rise over time, and total wave length.

The calcuation method used is essentially to look at the peaks, determine if they are rising or not, and then normalise the wave to [-1, 1]
with 0 DC rise over time, so it a relatively easy to find what is and isn't a peak. Looking back, probably a zero-crossing detection would
have been easier, but oh well.

This class is by far the messiest.
*/

#include "WaveRead.h" //Our superheader

namespace WaveRead //Don't mess up the std namespace.
{
	void wavereader::error_handler() //This is just a quick and dirty error function because the Windows error functions are *insane*.
	{
		DWORD lasterror = GetLastError(); 
		TCHAR* err = NULL;
		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
			NULL,
			lasterror,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPTSTR)&err,
			0,
			NULL);
		std::wcerr << err << std::endl;
		this->clear_data();
		LocalFree(err);
		err = nullptr;
	}

	wavereader::wavereader() //Simple constuctors and destructor. clear_data() resets all variables. 
	{
		file_buf = nullptr;
		this->clear_data();
	}

	wavereader::wavereader(std::wstring wavefile) //open() opens the file at the locations specified by the string wavefile, and loads all the csv data.
	{
		file_buf = nullptr;
		this->open(wavefile); //We don't need to call clear_data because open will do that.
	}

	wavereader::~wavereader()
	{
		this->clear_data();
	}

	void wavereader::open(std::wstring wavefile) //This opens the Wave csv at the location specified by the string wavefile
	{
		this->clear_data(); //Reset all variables, as we are getting totally new information
		filename = wavefile;
		fhandle = CreateFile(this->filename.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL); //Basically, open a file and return an error
																																	   //if it doesn't exist or we are not allowed to access it.
		if (this->fhandle == INVALID_HANDLE_VALUE) //This is usually on file non-existance, but it can also be on lack of permissions.
		{
			std::wcerr << filename;
			std::wcerr << TEXT(": Error opening file:") << std::endl; //Just give the user an basic idea of why we can't do this, and quit.
			error_handler();
			return;
		}
		bool getfilesize_ret = false;
		getfilesize_ret = GetFileSizeEx(this->fhandle, &(this->filesize)); //Get the size of the file so we can allocate the buffer reasonably.
		if (getfilesize_ret == false)
		{
			std::wcerr << filename;
			std::wcerr << TEXT(": Error getting file size:") << std::endl; //An error here is probably a serious I/O or memory error, it is unlikely to happen.
			error_handler();
			return;
		}
		char* file_buf_mb;
		file_buf_mb = new char[(unsigned int) filesize.QuadPart + 1]; //This is the multibyte, or UTF-8 file buffer. We need this because Win32 API seems to function
		if (file_buf_mb == nullptr)                                   //on widechar UTF-16 characters, so we need to first read it all, then quickly convert it all.
		{
			mem_error(); //If we can't get this buffer, likely the computer is out of memory. So give up.
			return;
		}
		file_buf = new TCHAR[(unsigned int) filesize.QuadPart + 1]; //This is the widechar buffer. We'll use this instead.
		if (file_buf == nullptr)
		{
			mem_error(); //If we can't get this buffer, likely the computer is out of memory. So give up.
			return;
		}
		bool readfile_ret = false; //This is just to check we read okay.
		DWORD bytes_read = 0;
		readfile_ret = ReadFile(this->fhandle, file_buf_mb, (DWORD)this->filesize.QuadPart, &bytes_read, NULL); //Again, if we have an issue here, it's likely an I/O error as we've
		if (readfile_ret == false)																				//checked permissions and existance already.
		{
			std::wcerr << TEXT("Error reading file:") << std::endl; //Run away
			error_handler();
			return;
		}
		file_buf_mb[filesize.QuadPart] = '\0'; //Zero terminate.
		MultiByteToWideChar(CP_UTF8, 0, file_buf_mb, -1, file_buf, (int)(filesize.QuadPart + 1)); //Convert from UTF-8 to UTF-16
		delete[] file_buf_mb; //Free memory we now aren't using.
		file_buf_mb = nullptr;
		CloseHandle(fhandle); //We can reliquish control of this file now, we have all the information in memory.
		fhandle = nullptr;
	}

	void wavereader::clear_data() //This is just a simple function to essentially
	{
		samples.clear(); //This is a vector of wavesamples, clear all of them in preperation for new data.
		start_time = -1; //Both of these are assumed to be doubles, but positive only (as time usually isn't measured with negative)
		end_time = -1;   //-1 is a convenient "unset" value.
		freq_found = false; //This is the flag that tells us if we have done the analysis or not, and whether to call find_freq in the sort or not.
		freq = 0;
		dc_gradient = 0; //This is the amount the signal moves up or down in voltage, on average, as time goes up
		complete = FALSE; //This is if it data has been converted to wavesample objects. It isn't that useful now, but if there is future asynchronous I/O,c could be.
		filename = TEXT(""); //This is the filename *with* the path given by the user. 
		fhandle = nullptr; 
		filesize.QuadPart = 0;
		if (file_buf != nullptr)
		{
			delete[] file_buf;
			file_buf = nullptr;
		}
	}

	std::wstring wavereader::get_filename() //This returns just the filename and extension as that looks nicer in the output csv file
	{
		TCHAR filename_only[FILENAME_MAX] = { 0 };
		TCHAR ext_only[FILENAME_MAX] = { 0 }; //Not what we want, but nessecary because of the function used
		std::wstring just_filename;

		_tsplitpath_s(filename.c_str(), NULL, 0, NULL, 0, filename_only, _MAX_FNAME, ext_only, _MAX_EXT); //This is why an extention buffer is needed as always splits into path/filename/extension

		just_filename = filename_only;
		just_filename.append(ext_only); //Just glue them back together

		return just_filename;
	}

	std::wstring wavereader::get_contents() //This isn't really that useful for the program as is, but was useful in debugging to dump the file data in memory.
	{
		if (this->file_buf == nullptr)
		{
			mem_error();
		}
		std::wstring retstr = this->file_buf;
		return retstr;
	}

	void wavereader::process() //This is the function that turns the file data in memory into wavesample objects with the measurement pairs.
	{
		csvreader *csv_reader = new csvreader(file_buf); //csvreader is a class that essentially extracts the measurements in a finite automata-like way
		int cadence = 0;                                 //It simply goes character by character, returning double values found in the text, delimited by
	                                                     //whatever value seperator (should be a comma but it works with others, though untested)
		                                                 //and then a newline.
		
		wavesample* sample = nullptr; //Our new wavesample
		while (true)
		{
			double val = csv_reader->nextval(); //The next valid double value
			if (isnan(val)) //NaN either means the end of the file, or an invalid value.
			{
				break;
			}
			if (cadence == 0) //The values come in the regular pattern time, voltage, time, etc... so we can use an easy modulo to determine which one
			{                 //Assuming csvreader is doing its job correctly.
				sample = new wavesample; //If the cadence is 0, it is a new time sample and therefore a new wave sample altogether.
				sample->set_time(val);   
				if (start_time == -1)    //If the first time of wave hasn't been set it's probably this one.
				{
					start_time = val;
				}
				if (val > end_time)      //Logically, the end time should be the largest time value.
				{
					end_time = val;
				}
			}
			else if (cadence == 1)       //If cadence is 1 it should be the voltage measurement.
			{
				sample->set_volts(val);
				samples.push_back(sample); //And it also means we are done with this sample.
			}
			cadence += 1; 
			cadence %= 2; //Ensure we get 0,1,0,1... repeating
		}
		delete[] file_buf; //Release memory we don't need
		file_buf = nullptr;
		complete = true; //The wavesample list is complete, all data from the csv should be in pairs of doubles now.
	}

	void wavereader::find_freq() //This is the function called when the frequence hasn't been found.
	{
		peaks.clear(); //Make sure we have no left over peak measurements
		this->find_peaks(); //Find the peaks
		this->calc_freq(); //Use those peaks to find the frequency
		freq_found = true; //Done! Don't do it again.
	}

	void wavereader::find_peaks() //This is probably the function that took me the most time. Finding exactly what is and isn't a true global peak, along with the
	{                             //true value of the DC gradient is hard! It took a lot of trial and error and probably *should* have been easier.
		                          //This is not a great piece of code, but it seems to work relatively reliably so long as the wave isn't too messy.

		bool ascending = false; //This is if the previous samples were all increasing, so we are headed for a positive peak
		bool descending = false; //This is if the previous samples were all decreasing, so we are headed for a negative peak
		peak_max = samples.at(0); //These are all the negative peaks, *includes* local minima that are not useful for the frequency measurement
		peak_min = samples.at(0); //These are all the negative peaks, *includes* local maxima that are not useful for the frequency measurement
		double max_gradient = 0; //This is the positive gradient, i.e.: the upwards direction of the highest peaks
		wavesample *last_max = nullptr; //This is a pointer to the last sample that was used for calculating the upwards gradient
		wavesample *gradient_max = nullptr; //This is a pointer to the current sample that was used for calculating the upwards gradient
		double min_gradient = 0; //This is the negative gradient, i.e.: the downwards direction of the lowest peaks
		wavesample *last_min = nullptr; //This is a pointer to the last sample that was used for calculating the downwards gradient
		wavesample *gradient_min = nullptr; //This is a pointer to the current sample that was used for calculating the downwards gradient
		std::vector <wavesample*> min_gradient_peaks; //This is a list of all the decreasing peaks
		std::vector <wavesample*> max_gradient_peaks; //This is a list of all the increasing peaks

		for (size_t i = 0; i < samples.size()-1; i++)
		{
			
			if (samples.at(i)->get_volts() <= peak_min->get_volts()) //If it is the lowest value we have seen, it's probably a peak (at least, once we at past the first anti-node)
			{
				peak_min = samples.at(i);	
				min_gradient_peaks.push_back(peak_min);
			}

			if (samples.at(i)->get_volts() >= peak_max->get_volts())  //If it is the highest value we have seen, it's probably a peak (at least, once we at past the first node)
			{
				peak_max = samples.at(i);
				max_gradient_peaks.push_back(peak_max);
			}

			if (samples.at(i)->get_volts() < samples.at(i + 1)->get_volts()) //If we notice that the next value is higher than this value...
			{
				if (ascending == false) //Then we're probably going up, so record that we are.
				{
					ascending = true;
				}
				if (descending == true) //If we *were* going down, that means we have some sort of maxima here, either local or global.
				{
					peaks.push_back(samples.at(i));
					descending = false;
				}
			}
			else if (samples.at(i)->get_volts() > samples.at(i + 1)->get_volts()) //If we notice that the next value is lower than this value...
			{
				if (descending == false) //Then we're probably going down, so record that we are.
				{
					descending = true;
				}
				if (ascending == true) //If we *were* going up, that means we have some sort of minima here, either local or global.
				{
					peaks.push_back(samples.at(i));
 					ascending = false;
				}
			}
		}

		remove_outliers(&max_gradient_peaks, true); //This attempts to remove the false positives at the beginning for maxima, as since the waves
		                                            //seem to increase by a constant, linear, amount the peaks per time should be constant as well. 

		if (max_gradient_peaks.size() > 1) //If we still have more than one highest point, we're probably going up (unless the signal is super noisy, which is dealt with later)
		{
			//Calculate the upwards dc gradient, assuming it is linear.
			max_gradient = (max_gradient_peaks.back()->get_volts() - max_gradient_peaks.at(1)->get_volts()) / (max_gradient_peaks.back()->get_time() - max_gradient_peaks.at(0)->get_time());
		}
		remove_outliers(&min_gradient_peaks, false);//This attempts to remove the false positives at the beginning for minima, as since the waves
		                                            //seem to decrease by a constant, linear, amount the peaks per time should be constant as well. 
		
		if (min_gradient_peaks.size() > 1) //If we still have more than one lowest point, we're probably going down (unless the signal is super noisy, which is dealt with later)
		{
			
			min_gradient = (min_gradient_peaks.back()->get_volts() - min_gradient_peaks.at(1)->get_volts()) / (min_gradient_peaks.back()->get_time() - min_gradient_peaks.at(0)->get_time());
		}


		if (peaks.size() == 4) //This is just for Wave41.csv, my nemesis. This program will *only* detect 4 peaks for that wave and the algorithm doesn't like that.
		{
			std::sort(peaks.begin(), peaks.end(), peak_sort); //Sort our peaks by voltage, so our positive and negative peaks are together
			min_gradient = (peaks.at(1)->get_volts() - peaks.at(0)->get_volts()) / (peaks.at(1)->get_time() - peaks.at(0)->get_time()); //Minimum peaks gradient
			max_gradient = (peaks.at(3)->get_volts() - peaks.at(2)->get_volts()) / (peaks.at(3)->get_time() - peaks.at(2)->get_time()); //Maximum peaks gradient

			dc_gradient = (max_gradient + min_gradient) / 2; //Average them for good measure
			std::sort(peaks.begin(), peaks.end(), time_sort); //Put the order back the way it was for other functions that assume the samples are in increase order of time.
			
		}
		else if (peak_max->get_time() > peak_min->get_time()) //If the wave has a constant upwards dc gradient, logically the highest peak must be the last.
		{
			if (peak_max->get_time() > (samples.back()->get_time() / 2)) //And it should lie after the halfway point of the wave, assuming at least 2 nodes.
			{
				dc_gradient = max_gradient;
			}
			else
			{
				dc_gradient = 0;
			}
		}
		else if (peak_max->get_time() < peak_min->get_time()) //If the wave has a constant downwards dc gradient, logically the lowest peak must be the last.
		{
			if (peak_min->get_time() > (samples.back()->get_time() / 2)) //And it should lie after the halfway point of the wave, assuming at least 2 anti-nodes.
			{
				dc_gradient = min_gradient;
			}
			else
			{
				dc_gradient = 0;
			}
		}
		else //If all else fails and we are just not sure, just average the two gradients and hopefully it will be close (for most waves, this averages to 0).
		{
			dc_gradient = (max_gradient + min_gradient) / 2;
		}
	}

	double wavereader::normal_value(wavesample* sample) //This normalised the voltage measurement to [-1, 1] for easier peak detection
	{
		double voltage_adjustment = dc_gradient * (sample->get_time() - wave_midpoint); //If there is a constant dc gradient, assume the midpoint is zero and subtract before, add after.
		return ((sample->get_volts() - voltage_adjustment) - dc_bias) / (amplitude / 2); //Because of the signs, subtract the gradient adjustment. After this remove the constant DC bias
	}                                                                                    //And normalise to [-1. 1].

	void wavereader::remove_outliers(std::vector<wavesample*>* list, bool ascending) //This is a (somewhat hacky) attempt to clean up noisy waves that trip the peak detection too much.
	{
		double last_time = samples.back()->get_time(); //Final sample time 
		double start_time = samples.at(0)->get_time(); //First sample time
		double peaks_per_time = list->size() / (last_time - start_time); //Assuming the dc gradient is constant, this should be the average amount of peaks per second.
		std::vector<wavesample*> erase_vec; //A list of samples to chuck
		int count_repeat_max = 0; //If we detect lots of repeated peaks, it probably actually doesn't have a dc gradient.
		
		for (size_t i = 1; i < list->size(); i++)
		{
			double expected_peaks = std::round((peaks_per_time * list->at(i)->get_time()) + 1); //Calculate the rough amount of peaks we should have at this point in time, plus 1 (rounding)
			
			if (list->at(i)->get_volts() >= list->at(i - 1)->get_volts() && ascending) //If we think that we are going up, but we see that we actually have
			{                                                                          //lower or equal peaks as go forward, we probably aren't.
				count_repeat_max++;
				if (count_repeat_max >= 3)                                             //If it happens three or more times, just assume the dc gradient is wrong.
				{
					list->clear();
					break;
				}
			}
			else if (list->at(i)->get_volts() <= list->at(i - 1)->get_volts() && !ascending) //If we think that we are going down, but we see that we actually have
			{                                                                                //higher or equal peaks as go in time, we probably aren't.
				count_repeat_max++;
				if (count_repeat_max >= 3)                                                   //If it happens three or more times, just assume the dc gradient is wrong.
				{
					list->clear();
					break;
				}
			}
			
			if (i > expected_peaks) //If we have more peaks than we expect at this point, remove this one.
			{	
				erase_vec.push_back(list->at(i));
			}
			else if (ascending)
			{
				// If we think that this has an ascending dc gradient, but this peak actually shows a decreasing gradient from the previous one, remove it.
				if (((list->at(i)->get_volts() - list->at(i - 1)->get_volts()) / (list->at(i)->get_time() - list->at(i - 1)->get_time())) <= 0) 
				{
					erase_vec.push_back(list->at(i));
				}
			}
			else if (!ascending)
			{
				// If we think that this has an descending dc gradient, but this peak actually shows a decreasing gradient from the previous one, remove it.
				if (((list->at(i)->get_volts() - list->at(i - 1)->get_volts()) / (list->at(i)->get_time() - list->at(i - 1)->get_time())) >= 0)
				{
					erase_vec.push_back(list->at(i));
				}
			}

		}

		for (size_t i = 0; i < erase_vec.size(); i++) //If we've decided to chuck any of the peak samples, do it now.
		{
			list->erase(std::remove(list->begin(), list->end(), erase_vec.at(i)), list->end());
		}
	}

	bool wavereader::peak_sort(wavesample* s1, wavesample* s2) //Sort wavesamples by voltage
	{
		return s1->get_volts() > s2->get_volts();
	}

	bool wavereader::time_sort(wavesample* s1, wavesample* s2) //Sort wavesamples by time
	{
		return s1->get_time() < s2->get_time();
	}

	bool wavereader::freq_sort(wavereader* w1, wavereader* w2) //Sort wave files by frequency
	{
		return w1->get_freq() < w2->get_freq();
	}

	double wavereader::group_peaks() //Assuming we have the correct information to normalise the wave, this function attempts to remove erroneous peaks by looking at groupings
	{                                //of positive and negative peaks, and choosing the highest before the normalised wave crosses zero.
		                             //It then sets the peak detection threshold for frequency calculation based on the lowest of those group maxima.
		
		bool positive_side = false; //Which side of zero are we?
		double pos_max_group = 0;  //Maximum (absolute value) of the positive values in the group
		double neg_max_group = 0;  //Maximum (absolute value) of the negative values in the group
		double pos_min_max = 2;    //Lowest positive group maxima, 2 is higher than any normalised value could be (as it is bound [-1, 1])
		double neg_min_max = -2;   //Highest negative group maxima, -2 is lower than any normalised value could be (as it is bound [-1, 1])
		double peak_limits = 0;    //Detection threshold for normalised peaks in frequency calculation

		for (size_t i = 0; i < peaks.size(); i++)
		{
			double normalised_val = normal_value(peaks.at(i));

			if (normalised_val > 0.3) //The peak *must* be *at least* more than a third the way to the maximum amplitude, more likely 99% of. Note: all DC affects removed with normalisation
			{
				positive_side = true; //Definitely the positive side if we are significantly greater than 0.
				pos_max_group = 0;    //Reset the maximum for this grouping
				if (neg_max_group < 0 && neg_max_group > neg_min_max) //Logically, if we were just doing the negative grouping and we are now in the positive, we are at the end of the negative.
				{
					neg_min_max = neg_max_group; //And if the maximum value of the group is less than the minimum overall negative threshold, change the threshold.
				}
			}
			else if(normalised_val < -0.3) //The peak *must* be *at least* more than a third the way to the maximum amplitude, more likely 99% of. Note: all DC affects removed with normalisation
			{
				positive_side = false; //Definitely the negative side if we are significantly less than 0.
				neg_max_group = 0; //Reset the maximum for this grouping
				if (pos_max_group > 0 && pos_max_group < pos_min_max) //Logically, if we were just doing the positive grouping and we are now in the negative, we are at the end of the positive.
				{
					pos_min_max = pos_max_group; //And if the maximum value of the group is less than the minimum overall positive threshold, change the threshold.
				}
			}
			
			if (positive_side) 
			{
				if (normalised_val > pos_max_group) //Find the highest in this group
				{
					pos_max_group = normalised_val;
				}
			}
			else
			{
				if (normalised_val < neg_max_group) //Find the highest in this group
				{
					neg_max_group = normalised_val;
					
				}
			}
		}

		double new_peak_limits = min(pos_min_max, std::fabs(neg_min_max)); //The threshold should be the low enough we catch peaks from both positive and negative
		peak_limits = std::nextafter(new_peak_limits, 0); //Set the threshold to be the nearest double below the required value
		return peak_limits;
	}

	void wavereader::calc_freq() //After all that bother finding peaks, use those peaks to calculate the frequency.
	{
		double low_time_avg = 0; //Average time between the negative peaks (anti-nodes)
		double low_time_count = 0; //Since it is a running average, take note of how many peaks
		double high_time_avg = 0; //Average time between the positive peaks (nodes)
		double high_time_count = 0; //Since it is a running average, take note of how many peaks
		double avg_period = 0; //Overall average period, which we invert to get frequency
		bool positive_last = false; //If the last peak was positive, the next *must* be negative or we messed up
		bool negative_last = false; //If the last peak was negative, the next *must* be positive or we messed up
		wavesample *last_low = nullptr; //The last negative peak we used for calculation
		wavesample *last_high = nullptr; //The last positive peak we used for calculation
		
		wave_len = samples.back()->get_time() - samples.at(0)->get_time(); //Total length of the wave in this file in time
		wave_midpoint = wave_len / 2; //Wave temporal midpoint for dc gradient calculations

		double peak_max_adjusted = peak_max->get_volts() - dc_gradient * (peak_max->get_time() - wave_midpoint); //Adjust the absolute peaks by the dc gradient to get the real AC peaks
		double peak_min_adjusted = peak_min->get_volts() - dc_gradient * (peak_min->get_time() - wave_midpoint);
		amplitude = peak_max_adjusted - peak_min_adjusted; //Real AC amplitude
		dc_bias = (peak_max_adjusted + peak_min_adjusted) / 2; //Actual constant DC bias

		min_normal_amp = this->group_peaks(); //Group and remove repeated/noisy peaks 

		for (size_t i = 0; i < peaks.size(); i++)
		{
			double normalised_val = normal_value(peaks.at(i)); //Get the normalised value from [-1, 1]

			if (normalised_val >= min_normal_amp && positive_last == false) //If this positive peak is higher than the detection threshold and the last peak wasn't positive
			{                                                               //It should be our guy!
				if (last_high != nullptr)                                   //If it is also not the first positive peak we have seen, we can calculate the period between peaks
				{
					double time_diff = peaks.at(i)->get_time() - last_high->get_time(); 
					high_time_avg = ((high_time_avg * high_time_count) + time_diff) / (high_time_count + 1); //Now use that period in a running average just to help with noise
					high_time_count++;
					
				}
				last_high = peaks.at(i);
				positive_last = true; 
				negative_last = false;
			}
			else if (normalised_val <= -min_normal_amp && negative_last == false) //If this negative peak is higher than the negative detection threshold and the last peak wasn't negative
			{                                                                     //It should be our guy!
				if (last_low != nullptr)                                          //If it is also not the first negative peak we have seen, we can calculate the period between peaks
				{
					double time_diff = peaks.at(i)->get_time() - last_low->get_time();
					low_time_avg = ((low_time_avg * low_time_count) + time_diff) / (low_time_count + 1); //Now use that period in a running average just to help with noise
					low_time_count++;
					
				}
				last_low = peaks.at(i);
				negative_last = true;
				positive_last = false;
			}

		}

		if (high_time_count > low_time_count) //If we have more positive peaks than negative, it's probably more accurate (from dc gradient estimation and trial and error, seems to be true)
		{
			avg_period = high_time_avg;
		}
		else if (high_time_count < low_time_count) //If we have more negative peaks than positive, it's probably more accurate (from dc gradient estimation and trial and error, seems to be true)
		{
			avg_period = low_time_avg;
		}
		else //Otherwise just average them
		{
			avg_period = (high_time_avg + low_time_avg) / 2;
		}

		freq = 1 / avg_period; //Invert for frequency.
	}

	bool wavereader::is_processed() //getter functions
	{
		return complete;
	}

	bool wavereader::is_freq_found()
	{
		return freq_found;
	}

	double wavereader::get_freq() //If the frequency is 0, we haven't tried to find it yet.
	{
		if (freq == 0)
		{
			this->find_freq();
		}
		return freq;
	}
}
