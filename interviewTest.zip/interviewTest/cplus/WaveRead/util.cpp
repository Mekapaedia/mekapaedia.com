/* WaveRead Version 1.0 by Ryan Harvey, submitted for consideration to Pico Technologies. */
/* Website: http://mekapaedia.com */
/* Email: rkharvey@mekapaedia.com */
/* This version completed as of the 24th of July, 2020. */
/* LICENSE INFORMATION: eh, would appreciate if you sent me a note if you use this, but honestly not fussed. Do what you want with this code. */
/* SUPPORT INFORMATION: email me I guess, but it's not really designed for commercial use. */

/*
util.cpp

This file is for utility functions and I/O functions that are globally useful but have no specific theme or need to be an a class.

*/

#include "WaveRead.h"

namespace WaveRead
{
	std::wstring VERSION_STRING = TEXT("1.0"); //Version v1 for submission? How convienent!
	bool FINISHED = true; //Hopefully!

	std::wstring wavearguments::OUTPUT_FILE = TEXT("");
	std::wstring wavearguments::OUTPUT_DIR = TEXT("");
	std::wstring wavearguments::CSV_SEPERATOR = TEXT(", "); //This is the seperator for the output file. It could be user specified, but isn't at the moment
	bool wavearguments::OUTPUT_DIR_SPECIFIED = false;
	bool wavearguments::OUTPUT_FILE_SPECIFIED = false;
	size_t wavearguments::START_VAL = 0;
	size_t wavearguments::END_VAL = INT32_MAX;
	bool wavearguments::VERBOSE = false; //If this is false, the program will only output errors or with -o - the results to the console

	void mem_error() //If we find a memory error, just tell the user and quit.
	{
		std::wcerr << TEXT("Either the system is out of memory or there is a serious memory error. Bailing.") << std::endl;
		exit(EXIT_FAILURE);
	}

	void io_error() //Quick and direct I/O error function because FormatMessage is insane.
	{
		std::wcerr << TEXT("I/O Error: ") << std::endl;
		DWORD lasterror = GetLastError();
		TCHAR* err = NULL;
		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
			NULL,
			lasterror,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPTSTR)&err,
			0,
			NULL);
		std::wcerr << err << std::endl;
		LocalFree(err);
		exit(EXIT_FAILURE);
	}

	void help() //The help and information function. Useful!
	{
		std::wcout << TEXT("Welcome to WaveRead v") + VERSION_STRING + TEXT(" by Ryan Harvey\n") << std::endl;
		std::wcout << TEXT("This program takes all the files in a specified directory with the format Wave*.csv and outputs a CSV file detailing the frequency of each file.") << std::endl;
		std::wcout << TEXT("By default, that file will be called WaveRead$TIMESTAMP.csv and will be saved in the current directory.") << std::endl;
		std::wcout  << std::endl;
		if (!FINISHED)
		{
			std::wcout << TEXT("(or at least, it should. This version isn't finished yet.)") << std::endl;
		}
		std::wcout << TEXT("\nUsage is as follows:") << std::endl;
		std::wcout << TEXT("-h: This help") << std::endl;
		std::wcout << TEXT("-d $DIRECTORY: Specify the directory to search for Wave files in. If unspecified, the current working directory will be used.") << std::endl;
		std::wcout << TEXT("-D $DIRECTORY: Specify the directory to output the analysis file. If unspecified, the current working directory will be used.") << std::endl;
		std::wcout << TEXT("-o $OUTPUT_FILE: Specify the full path of the output file. -D will be ignored if this is specified. If - is used the output will be the console.") << std::endl;
		std::wcout << TEXT("-v: Extra information on what the program is actually doing. Put in because with 420 files, the program takes ages.") << std::endl;
		std::wcout << TEXT("-f n: Assuming the Wave*.csv files are numbered in increasing monotonic order, this option is to skip n-1 files and start with file n. Zero indexed.") << std::endl;
		std::wcout << TEXT("-l n: Assuming the Wave*.csv files are numbered in increasing monotonic order, this option is to stop on file n. Zero indexed.") << std::endl;
	}

	void unique_add_seperator(std::vector<TCHAR> *list, TCHAR c, TCHAR prev_c) //This function is used with the candidate_seperator vector to find the one true seperator
	{                                                                          //Basically, while searching through the header, all non-alphanumber characters will be checked with this function
		                                                                       //If there is a character that appears once and only once, we assume it is the seperator, which is true for all
		                                                                       //CSV files that do not have quoted fields.
		                                                                       //Space needs to be treated specially as a space is normal after the seperator, but space can *also* be a sepeator.
		bool found = false;                                                  
		size_t found_at = 0;
		bool prev_found = false;
		bool is_space = false;

		TCHAR space_char = TEXT(' '); 

		if (c == space_char)
		{		
			is_space = true; //It's a space.
		}

		for (size_t i = 0; i < list->size(); i++) //Check if the character has been added to the list of candidate seperators
		{
			if (list->at(i) == c) //If it has, record where so we can delete it
			{
				found = true;
				found_at = i;
			}
			if (list->at(i) == prev_c) //If the *previous* character is found, just record that so if we are dealing with a space we can ignore it
			{
				prev_found = true;
			}
		}
		if (found == false) //If we don't find the characteer in the list, add it
		{
			if (is_space) //If we are dealing with the space character, check that it does not come after another candidate
			{             //Because that's likely "field1, field2"
				if (!prev_found) //If it doesn't, it might be a seperator
				{
					list->push_back(c);
				}
			}
			else //If it's not a space and we haven't seen it before, it might be a seperator.
			{
				list->push_back(c);
			}
		}
		else //Erase the one we found again.
		{
			list->erase(list->begin() + found_at);
		}
	}

	bool isvalid_floatwc(TCHAR c) //This returns true if the character is a valid character in either the standard decimal float notation or scientific notation
	{
		if (iswdigit(c)) //Obviously if it is a digit it is fine
		{
			return true;
		}
		else if (c == TEXT('-') || c == TEXT('+')) //Leading +/- or E+whatever
		{
			return true;
		}
		else if (c == TEXT('e') || c == TEXT('E')) //Exponent scientific notation
		{
			return true;
		}
		else if (c == TEXT('.')) //Decimal
		{
			return true;
		}
		else //None of these? Probably not a number.
		{
			return false;
		}
	}

	std::wstring readargs(int argc, _TCHAR* argv[]) //This function directly processes the command line arguments
	{
		bool DIRECTORY_SET = false; //This is the search directory, if it isn't specified use the current working directory.
		TCHAR *directory_buf = new TCHAR[FILENAME_MAX+1];

		if (directory_buf == nullptr) //Likely machine is out of memory if we cannot get a new TCHAR[]; just bail
		{
			mem_error();
			return NULL;
		}
		memset(directory_buf, 0, sizeof(directory_buf)); //Zero everything

		for (int i = 0; i < argc; i++) //Main argument processing loop
		{
			if (_tcscmp(TEXT("-h"), argv[i]) == 0) //Help
			{
				help();
				exit(EXIT_SUCCESS); //Another happy customer
			}

			if (_tcscmp(TEXT("-v"), argv[i]) == 0) //The user wants more talky talky
			{
				wavearguments::VERBOSE = true;
			}

			if (_tcscmp(TEXT("-f"), argv[i]) == 0) //This is for the first wave file to start with, mostly used for debugging. -f because "first"?
			{
				if ((i + 1) >= argc || _tcscnlen(argv[i + 1], FILENAME_MAX) < 1) //If there is not another argument after this, there is no value to process.
				{
					std::cerr << "No starting value specified." << std::endl;
					help();
					exit(EXIT_FAILURE);
				}
				TCHAR* first_num_buf = new TCHAR[FILENAME_MAX + 1]; //FILENAME_MAX is overkill for an integer but it's 2020 and an extra few bytes is fine.
				_tcsncpy_s(first_num_buf, _tcscnlen(argv[i + 1], FILENAME_MAX) + 1, argv[i + 1], _TRUNCATE); //Copy (UTF-16 widechar copy) the number string over
				wavearguments::START_VAL = _tcstol(first_num_buf, NULL, 10); //Convert that string to an integer
				if (errno != 0) //If there is an error in conversion, the output is just zero, which is actually a valid conversion, but errno is set to non-zero so we can detect it
				{
					std::cerr << "Invalid value specified." << std::endl; //There's no point assuming what the user might have wanted, just quit
					help();
					exit(EXIT_FAILURE);
				}
			}

			if (_tcscmp(TEXT("-l"), argv[i]) == 0) //This is for the last wave file to start with, mostly used for debugging. -l because "last"?
			{
				if ((i + 1) >= argc || _tcscnlen(argv[i + 1], FILENAME_MAX) < 1) //If there is not another argument after this, there is no value to process.
				{
					std::cerr << "No ending value specified." << std::endl;
					help();
					exit(EXIT_FAILURE);
				}
				TCHAR* last_num_buff = new TCHAR[FILENAME_MAX + 1]; //FILENAME_MAX is overkill for an integer but it's 2020 and an extra few bytes is fine.
				_tcsncpy_s(last_num_buff, _tcscnlen(argv[i + 1], FILENAME_MAX) + 1, argv[i + 1], _TRUNCATE); //Copy (UTF-16 widechar copy) the number string over
				wavearguments::END_VAL = _tcstol(last_num_buff, NULL, 10); //Convert that string to an integer
				if (errno != 0) //If there is an error in conversion, the output is just zero, which is actually a valid conversion, but errno is set to non-zero so we can detect it
				{
					std::cerr << "Invalid value specified." << std::endl; //There's no point assuming what the user might have wanted, just quit
					help();
					exit(EXIT_FAILURE);
				}
			}

			if (_tcscmp(TEXT("-d"), argv[i]) == 0) //This is the option for the input search directory, where the Wave*.csv files are
			{
				if ((i + 1) >= argc || _tcscnlen(argv[i + 1], FILENAME_MAX) < 1) //If there is not another argument after this, there is no value to process.
				{
					std::cerr << "No input directory specified." << std::endl;
					help();
					exit(EXIT_FAILURE);
				}
				DIRECTORY_SET = true; //We have a directory, so don't bother trying to find the current working directory
				_tcsncpy_s(directory_buf, _tcscnlen(argv[i + 1], FILENAME_MAX) + 1, argv[i + 1], _TRUNCATE); //Copy the directory path over
			}

			if (_tcscmp(TEXT("-o"), argv[i]) == 0) //This is the option for the output file save location and name
			{
				if ((i + 1) >= argc || _tcscnlen(argv[i + 1], FILENAME_MAX) < 1) //If there is not another argument after this, there is no value to process. 
				{
					std::cerr << "No output file specified." << std::endl;
					help();
					exit(EXIT_FAILURE);
				}
				wavearguments::OUTPUT_FILE_SPECIFIED = true; //Make use this path instead of the timestamp one
				TCHAR* output_file_buf = new TCHAR[FILENAME_MAX + 1];
				_tcsncpy_s(output_file_buf, _tcscnlen(argv[i + 1], FILENAME_MAX) + 1, argv[i + 1], _TRUNCATE);
				wavearguments::OUTPUT_FILE = output_file_buf; //Save the filename
				if (wavearguments::OUTPUT_DIR_SPECIFIED) //If both an output directory and an output path are specified, the user has made a mistake
				{                                        //It makes more sense to go with the path as it has the exact filename; but at least tell the user.

					std::cerr << "Both output directory and output file specified. Ignoring directory." << std::endl;
				}

			}

			if (_tcscmp(TEXT("-D"), argv[i]) == 0) //This is the output directory for the generated timestamped filename
			{                                      //Likely more useful if this was used in a script

				if ((i + 1) >= argc || _tcscnlen(argv[i + 1], FILENAME_MAX) < 1) //If there is not another argument after this, there is no value to process. 
				{
					std::cerr << "No output directory specified." << std::endl;
					help();
					exit(EXIT_FAILURE);
				}
				wavearguments::OUTPUT_DIR_SPECIFIED = true; //Make use this path instead of the current working directory
				TCHAR* output_directory_buf = new TCHAR[FILENAME_MAX + 1];
				_tcsncpy_s(output_directory_buf, _tcscnlen(argv[i + 1], FILENAME_MAX) + 1, argv[i + 1], _TRUNCATE);
				wavearguments::OUTPUT_DIR = output_directory_buf; //Save the directory path
				if (wavearguments::OUTPUT_FILE_SPECIFIED)//If both an output directory and an output path are specified, the user has made a mistake
				                                         //It makes more sense to go with the path as it has the exact filename; but at least tell the user.
				{
					std::cerr << "Both output directory and output file specified. Ignoring directory." << std::endl;
				}
			}
		}

		if (DIRECTORY_SET == false) //If the output directory isn't specified by the user, find the current working directory and use that.
		{
			GetCurrentDirectory(MAX_PATH, directory_buf);
		}
		return directory_buf;
	}

	void write_output(std::vector<wavereader*> *wavelist, size_t start_val, size_t end_val) //This function is a little too long, but it is a casuality of trying to internally use Microsoft's
	{                                                                                       //suggested UTF-16 widechar encoding while sticking with a sane output encoding.
		                                                                                    //Essentially, this function handles both converting all the wave information into characters,
		                                                                                    //formatting those characters, then converting that from UTF-16 widechars to a UTF-8 multibyte
		                                                                                    //encoding, then handles the output of the UTF-8 information either to a file or the console.
		                                                                                    //I miss ANSI encoding.
		SYSTEMTIME curr_time; //Used for generating a timestamp
		GetSystemTime(&curr_time);
		TCHAR *time_string_buf = new TCHAR[FILENAME_MAX]; //Timestamp output buffer
		TCHAR *directory_buf = new TCHAR[FILENAME_MAX]; //Used for getting the current directory
		TCHAR *output_buf = new TCHAR[FILENAME_MAX]; //This is the filename buffer for sprintf and the like
		std::vector <char*> csv_buf; //This contains an array of UTF-8 lines to directly be written to a file
		TCHAR *line_buf = new TCHAR[1024]; //A buffer for a single UTF-16 widechar line
		char *line_buf_utf8 = new char[1024]; //A buffer for a single UTF-8 multibyte line
		size_t line_buf_size = 1024 * sizeof(TCHAR);
		size_t line_buf_utf8_size = 1024 * sizeof(char);
		std::wstring output = TEXT(""); //Output path string
		std::wstring directory = TEXT(""); //Output directory string
		size_t time_string_buf_size = FILENAME_MAX * sizeof(TCHAR);
		size_t output_buf_size = FILENAME_MAX * sizeof(TCHAR);
		size_t line_len = 0; //Length of the current UTF-16 widechar line for conversion

		//This is the call for generating the timestamp. It uses a millisecond precision so *hopefully* no two timestamps are the same.
		StringCbPrintf(time_string_buf, time_string_buf_size, TEXT("%04u%02u%02u-%02u%02u%02u_%03u"), curr_time.wYear, curr_time.wMonth, curr_time.wDay, curr_time.wHour, curr_time.wMinute, curr_time.wSecond, curr_time.wMilliseconds);
		//Get the current directory
		GetCurrentDirectory(MAX_PATH, directory_buf);

		memset(line_buf, 0, line_buf_size); //Zero both line buffers
		memset(line_buf_utf8, 0, line_buf_utf8_size);
		StringCbPrintf(line_buf, line_buf_size, TEXT("%s%s%s\r\n"), TEXT("Filename"), wavearguments::CSV_SEPERATOR.c_str(), TEXT("Frequency (Hz)")); //Write the headers to the line buffer
		WideCharToMultiByte(CP_UTF8, 0, line_buf, _tcscnlen(line_buf, line_buf_size), line_buf_utf8, line_buf_utf8_size, NULL, NULL); //Convert to UTF-8 multibyte encoding
		csv_buf.push_back(line_buf_utf8); //Add that to the list of lines to output
		
		for (size_t i = start_val; i < end_val; i++) //For each file, do the same output and conversion.
		{
			line_buf = new TCHAR[1024]; //Get new buffers. 1024 *should* be enough, way enough.
			line_buf_utf8 = new char[1024];
			memset(line_buf, 0, line_buf_size); //Zero both line buffers
			memset(line_buf_utf8, 0, line_buf_utf8_size);
			//Write the filename (without the path because it looks nicer) and the frequency in scientific notation. I've used \r\n because we are on Windows.
			StringCbPrintf(line_buf, line_buf_size, TEXT("%s%s%E\r\n"), wavelist->at(i)->get_filename().c_str(), wavearguments::CSV_SEPERATOR.c_str(), wavelist->at(i)->get_freq());
			//Convert that line to UTF-8 multibyte encoding
			WideCharToMultiByte(CP_UTF8, 0, line_buf, _tcscnlen(line_buf, line_buf_size), line_buf_utf8, line_buf_utf8_size, NULL, NULL);
			csv_buf.push_back(line_buf_utf8); //Add that to the list of lines to output
		}
		
		if (wavearguments::OUTPUT_FILE == TEXT("-")) //If - is specified, it means output to the console (stdout)
		{
			for (size_t i = 0; i < csv_buf.size(); i++) //Output each line to the console
			{
				std::cout << csv_buf.at(i);
			}
			return; //We're done, so quit.
		}
		else if (wavearguments::OUTPUT_FILE.size() > 2) //The output file string has to be more than one character and the zero terminator
		{
			StringCbPrintf(output_buf, output_buf_size, TEXT("%s"), wavearguments::OUTPUT_FILE.c_str());
			output = output_buf;
		}
		else if (wavearguments::OUTPUT_DIR.size() > 2) //The output dir string string has to be more than one character and the zero terminator
		{
			//Add on to the directory the filename, containing WaveRead, the timestamp, and the csv extension
			StringCbPrintf(output_buf, output_buf_size, TEXT("%s\\WaveRead%s.csv"), wavearguments::OUTPUT_DIR.c_str(), time_string_buf);
			output = output_buf;
		}
		else if (wavearguments::OUTPUT_FILE == TEXT("")) //If there is no output dir and no output file, use the current working directory (also works for "."!)
		{
			//Add on to the directory the filename, containing WaveRead, the timestamp, and the csv extension
			StringCbPrintf(output_buf, output_buf_size, TEXT("%s\\WaveRead%s.csv"), directory_buf, time_string_buf);
			output = output_buf;			
		}
		else //This shouldn't happen, but if it does, at least give some indication where in the code the error is from.
		{
			std::wcerr << "Error finding output file" << std::endl; 
			exit(EXIT_FAILURE);
		}

		if (wavearguments::VERBOSE) //If we're feeling talkative, say where the data is saved.
		{
			std::wcout << TEXT("Output file is ") + output << std::endl;
		}

		//This is a handle to the file want to write to. It will fail if we don't have permissions or the file exists
		HANDLE outhandle = CreateFile(output.c_str(), GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
		if (outhandle == INVALID_HANDLE_VALUE) //If it does fail, complain and quit
		{
			io_error();
		}
		for (size_t i = 0; i < csv_buf.size(); i++) //If everything is okay with the file, write each UTF-8 multibyte encoded line to it.
		{
			bool write_ret = WriteFile(outhandle, csv_buf.at(i), strlen(csv_buf.at(i)), NULL, NULL);
			if (!write_ret) //If there is a writing error of any kind at this stage, likely there is a serious I/O error so don't bother trying to fix it.
			{
				io_error();
			}

		}
		CloseHandle(outhandle); //Finish up!
	}

}