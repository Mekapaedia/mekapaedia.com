/* WaveRead Version 1.0 by Ryan Harvey, submitted for consideration to Pico Technologies. */
/* Website: http://mekapaedia.com */
/* Email: rkharvey@mekapaedia.com */
/* This version completed as of the 24th of July, 2020. */
/* LICENSE INFORMATION: eh, would appreciate if you sent me a note if you use this, but honestly not fussed. Do what you want with this code. */
/* SUPPORT INFORMATION: email me I guess, but it's not really designed for commercial use. */

/* 
WaveRead.cpp

This is main entry point of the code. It handles getting arguments, choosing what files to read, ensuring each file is turned into a wavesample data structure, 
and getting output written. I am a proponent of small main functions.
*/

#include "WaveRead.h" //Yes, one universal header file. Only because it's a small program and its easier to keep track of one list of includes.

using namespace std;

int _tmain(int argc, _TCHAR* argv[]) //Using tmain because I'm still learning multibyte encoding on Windows, and this was suggested as the correct way to do so.
{									 //I'm found out recently that is outdated information... I wish everything just used UTF-8.
	wstring directory = TEXT("");

	directory = WaveRead::readargs(argc, argv); //readargs effectively reals all of the command line arguments, and sets the relevent global variables (output file, input directory, etc)
	wstring search_directory = directory.c_str(); //This might seem like a useless bit of code, but search_directory is intended to be the search string in FindFirstFile
	search_directory.append(TEXT("\\*"));         //While directory is actually the *specified* directory, so we can feed that back to the user as information if they specify verbosity.

	if (WaveRead::wavearguments::VERBOSE)
	{
		wcout << TEXT("Searching for WaveGen files in directory ") + directory << endl;
	}
	
	WIN32_FIND_DATA data; //Use proper WIN32 methods for finding files
	HANDLE hFind;
	vector<WaveRead::wavereader *> wavelist; //The big list of waves from each file, this does the bulk of the heavy lifting.

	hFind = FindFirstFile(search_directory.c_str(), &data); //Do the search and error checking
	if (hFind == INVALID_HANDLE_VALUE)
	{
		wcerr << endl << TEXT("Invalid directory ") + directory + TEXT(" specified") << endl;
		exit(EXIT_FAILURE);
	}
	else
	{
		while (FindNextFile(hFind, &data) != 0) //Continue to find all the files in the directory that match Wave*.csv, which is the format provided.
		{
			if((_tcsstr(data.cFileName, TEXT("Wave")) != NULL) && (_tcsstr(data.cFileName, TEXT(".csv")) != NULL))
			{
				WaveRead::wavereader *target = new WaveRead::wavereader(directory + TEXT("\\") + data.cFileName);
				wavelist.push_back(target);
			}
		}
		FindClose(hFind);
	}

	if (WaveRead::wavearguments::VERBOSE)
	{
		wcout << to_wstring(wavelist.size()) + TEXT(" WaveGen files found.") << endl;
	}
	
	//This section only really exists because each run was taking around 15 minutes to process all 420 files
	//I am at a loss why it takes so long - I imagine something to do with synchronous I/O - but when you're tweaking small things, you really need to limit it to just a few files.

	size_t start_val = WaveRead::wavearguments::START_VAL;
	size_t digested = start_val;
	
	size_t break_val = WaveRead::wavearguments::END_VAL;
	size_t end_val = ((break_val < wavelist.size()) ? (break_val+1) : wavelist.size()); //Cheeky ternany operator; just choose the smaller of last file specified or the last file in the list
																						//Luckily, size_t is unsigned or this simple ternany operator could get us in real trouble with bad input

	if (WaveRead::wavearguments::VERBOSE)
	{
		wcout << TEXT("Analysing files ") << to_wstring(start_val) + TEXT(" to ") + to_wstring(end_val) + TEXT(" (") + to_wstring(end_val - start_val) + TEXT(" files).") << endl;
	}
	
	if (WaveRead::wavearguments::VERBOSE)
	{
		printf("Digested %u/%u wave files", digested - start_val, end_val - start_val);
	}
	
	for (size_t i = start_val; i < end_val; i++) //process() converts the in-memory text buffer to a list of wavesample objects representing each pair of measurements in the csv file
	{                                            //This takes by far the longest time. Not sure why. 
		wavelist.at(i)->process();
		digested++;
		if (WaveRead::wavearguments::VERBOSE)
		{
			printf("\rDigested %u/%u wave files", digested - start_val, end_val - start_val);
		}
		if (i >= break_val)
		{
			break;
		}
	}
	if (WaveRead::wavearguments::VERBOSE)
	{
		printf("\n");
	}

	sort(wavelist.begin() + start_val, wavelist.begin() + end_val, WaveRead::wavereader::freq_sort); //This actually does all the analysis. It's a bit of a chain but not too hard to explain:
	                                                                                                 //On comparison, freq_sort calls wavereader::get_freq(), which if the frequency hasn't
	                                                                                                 //yet been calculated, calls wavereader::find_freq(), which calculates the frequency.
	                                                                                                 //If it has been calculated, it just returns the frequency. 
	                                                                                                 //Surprisingly, this doesn't long.
	WaveRead::write_output(&wavelist, start_val, digested); //Write to either console or file
	
	if (WaveRead::wavearguments::VERBOSE)
	{
		wcout << TEXT("Analysis complete.") << endl;
	}
	
	wavelist.clear(); //Clean up
}